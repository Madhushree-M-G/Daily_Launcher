from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import json
import re
import validators
import uuid
import os
from urllib.parse import urlparse

app = Flask(__name__)
CORS(app)

# Database configuration
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{os.path.join(basedir, "daily_launcher.db")}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your-secret-key-here'

db = SQLAlchemy(app)

# Models
class Collection(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    urls = db.Column(db.Text, nullable=False)  # JSON string
    tags = db.Column(db.Text)  # JSON string
    window_positions = db.Column(db.Text)  # JSON string
    delay_seconds = db.Column(db.Integer, default=1)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    usage_count = db.Column(db.Integer, default=0)
    last_used = db.Column(db.DateTime)
    share_id = db.Column(db.String(36), unique=True)
    is_public = db.Column(db.Boolean, default=False)
    theme = db.Column(db.String(20), default='gradient-blue')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'urls': json.loads(self.urls) if self.urls else [],
            'tags': json.loads(self.tags) if self.tags else [],
            'window_positions': json.loads(self.window_positions) if self.window_positions else {},
            'delay_seconds': self.delay_seconds,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'usage_count': self.usage_count,
            'last_used': self.last_used.isoformat() if self.last_used else None,
            'share_id': self.share_id,
            'is_public': self.is_public,
            'theme': self.theme
        }

# Utility functions
def validate_url(url):
    """Validate and normalize URL"""
    if not url.strip():
        return None, "URL cannot be empty"
    
    # Add https:// if no protocol specified
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    
    # Validate URL format
    if not validators.url(url):
        return None, "Invalid URL format"
    
    return url, None

def generate_share_id():
    """Generate unique share ID"""
    return str(uuid.uuid4())

def create_sample_data():
    """Create sample data if no collections exist"""
    if Collection.query.count() == 0:
        sample_collections = [
            {
                "name": "Development Tools",
                "description": "Essential development websites",
                "urls": ["https://github.com", "https://stackoverflow.com", "https://developer.mozilla.org"],
                "tags": ["development", "coding", "resources"],
                "theme": "gradient-purple"
            },
            {
                "name": "Social Media",
                "description": "Daily social media check",
                "urls": ["https://twitter.com", "https://linkedin.com", "https://reddit.com"],
                "tags": ["social", "networking"],
                "theme": "gradient-pink"
            }
        ]
        
        for sample in sample_collections:
            collection = Collection(
                name=sample["name"],
                description=sample["description"],
                urls=json.dumps(sample["urls"]),
                tags=json.dumps(sample["tags"]),
                window_positions=json.dumps({}),
                delay_seconds=1,
                share_id=generate_share_id(),
                theme=sample["theme"]
            )
            db.session.add(collection)
        
        db.session.commit()

# Routes
@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({"status": "healthy", "message": "Daily Launcher API is running"})

@app.route('/api/collections', methods=['GET'])
def get_collections():
    try:
        collections = Collection.query.order_by(Collection.updated_at.desc()).all()
        return jsonify({
            "success": True,
            "collections": [col.to_dict() for col in collections]
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/collections', methods=['POST'])
def create_collection():
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('name'):
            return jsonify({"success": False, "error": "Collection name is required"}), 400
        
        if not data.get('urls') or len(data.get('urls', [])) == 0:
            return jsonify({"success": False, "error": "At least one URL is required"}), 400
        
        # Validate URLs
        validated_urls = []
        for url in data.get('urls', []):
            validated_url, error = validate_url(url)
            if error:
                return jsonify({"success": False, "error": f"Invalid URL '{url}': {error}"}), 400
            validated_urls.append(validated_url)
        
        # Create collection
        collection = Collection(
            name=data['name'],
            description=data.get('description', ''),
            urls=json.dumps(validated_urls),
            tags=json.dumps(data.get('tags', [])),
            window_positions=json.dumps(data.get('window_positions', {})),
            delay_seconds=data.get('delay_seconds', 1),
            share_id=generate_share_id(),
            is_public=data.get('is_public', False),
            theme=data.get('theme', 'gradient-blue')
        )
        
        db.session.add(collection)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Collection created successfully",
            "collection": collection.to_dict()
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/collections/<int:collection_id>', methods=['PUT'])
def update_collection(collection_id):
    try:
        collection = Collection.query.get_or_404(collection_id)
        data = request.get_json()
        
        # Validate URLs if provided
        if 'urls' in data:
            validated_urls = []
            for url in data['urls']:
                validated_url, error = validate_url(url)
                if error:
                    return jsonify({"success": False, "error": f"Invalid URL '{url}': {error}"}), 400
                validated_urls.append(validated_url)
            collection.urls = json.dumps(validated_urls)
        
        # Update other fields
        if 'name' in data:
            collection.name = data['name']
        if 'description' in data:
            collection.description = data['description']
        if 'tags' in data:
            collection.tags = json.dumps(data['tags'])
        if 'window_positions' in data:
            collection.window_positions = json.dumps(data['window_positions'])
        if 'delay_seconds' in data:
            collection.delay_seconds = data['delay_seconds']
        if 'is_public' in data:
            collection.is_public = data['is_public']
        if 'theme' in data:
            collection.theme = data['theme']
        
        collection.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Collection updated successfully",
            "collection": collection.to_dict()
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/collections/<int:collection_id>', methods=['DELETE'])
def delete_collection(collection_id):
    try:
        collection = Collection.query.get_or_404(collection_id)
        db.session.delete(collection)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Collection deleted successfully"
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/collections/<int:collection_id>/launch', methods=['POST'])
def launch_collection(collection_id):
    try:
        collection = Collection.query.get_or_404(collection_id)
        
        # Update usage statistics
        collection.usage_count += 1
        collection.last_used = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Collection launched successfully",
            "collection": collection.to_dict()
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/collections/share/<share_id>', methods=['GET'])
def get_shared_collection(share_id):
    try:
        collection = Collection.query.filter_by(share_id=share_id, is_public=True).first()
        if not collection:
            return jsonify({"success": False, "error": "Shared collection not found"}), 404
        
        return jsonify({
            "success": True,
            "collection": collection.to_dict()
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/collections/import', methods=['POST'])
def import_collections():
    try:
        data = request.get_json()
        collections_data = data.get('collections', [])
        
        imported_count = 0
        errors = []
        
        for col_data in collections_data:
            try:
                # Validate URLs
                validated_urls = []
                for url in col_data.get('urls', []):
                    validated_url, error = validate_url(url)
                    if error:
                        errors.append(f"Skipped collection '{col_data.get('name')}': Invalid URL '{url}'")
                        continue
                    validated_urls.append(validated_url)
                
                if not validated_urls:
                    continue
                
                collection = Collection(
                    name=col_data.get('name', 'Imported Collection'),
                    description=col_data.get('description', ''),
                    urls=json.dumps(validated_urls),
                    tags=json.dumps(col_data.get('tags', [])),
                    window_positions=json.dumps(col_data.get('window_positions', {})),
                    delay_seconds=col_data.get('delay_seconds', 1),
                    share_id=generate_share_id(),
                    is_public=False,
                    theme=col_data.get('theme', 'gradient-blue')
                )
                
                db.session.add(collection)
                imported_count += 1
                
            except Exception as e:
                errors.append(f"Error importing collection '{col_data.get('name')}': {str(e)}")
        
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": f"Successfully imported {imported_count} collections",
            "imported_count": imported_count,
            "errors": errors
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/collections/export', methods=['GET'])
def export_collections():
    try:
        collections = Collection.query.all()
        export_data = {
            "export_date": datetime.utcnow().isoformat(),
            "version": "1.0",
            "collections": [col.to_dict() for col in collections]
        }
        
        return jsonify({
            "success": True,
            "data": export_data
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/stats', methods=['GET'])
def get_stats():
    try:
        total_collections = Collection.query.count()
        total_urls = sum(len(json.loads(col.urls or '[]')) for col in Collection.query.all())
        most_used = Collection.query.order_by(Collection.usage_count.desc()).limit(5).all()
        recent_collections = Collection.query.order_by(Collection.created_at.desc()).limit(5).all()
        
        # Tag statistics
        all_tags = []
        for col in Collection.query.all():
            tags = json.loads(col.tags or '[]')
            all_tags.extend(tags)
        
        tag_counts = {}
        for tag in all_tags:
            tag_counts[tag] = tag_counts.get(tag, 0) + 1
        
        return jsonify({
            "success": True,
            "stats": {
                "total_collections": total_collections,
                "total_urls": total_urls,
                "most_used": [col.to_dict() for col in most_used],
                "recent_collections": [col.to_dict() for col in recent_collections],
                "popular_tags": sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)[:10]
            }
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/validate-url', methods=['POST'])
def validate_url_endpoint():
    try:
        data = request.get_json()
        url = data.get('url', '')
        
        validated_url, error = validate_url(url)
        
        if error:
            return jsonify({
                "success": False,
                "error": error,
                "valid": False
            })
        
        # Get additional URL info
        parsed = urlparse(validated_url)
        
        return jsonify({
            "success": True,
            "valid": True,
            "url": validated_url,
            "domain": parsed.netloc,
            "protocol": parsed.scheme
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        # Create sample data if no collections exist
        create_sample_data()
    app.run(debug=True, host='0.0.0.0', port=5000)