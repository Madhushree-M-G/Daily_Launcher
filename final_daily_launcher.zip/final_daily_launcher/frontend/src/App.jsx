import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Edit2, 
  Play, 
  Share2, 
  Download, 
  Upload, 
  Search,
  Tag,
  Clock,
  BarChart3,
  Moon,
  Sun,
  Rocket,
  Globe,
  Settings,
  Heart,
  Star,
  TrendingUp,
  Calendar,
  Zap,
  Target,
  Bookmark,
  Link,
  Eye,
  EyeOff
} from 'lucide-react';
import toast, { Toaster } from 'react-hot-toast';

const API_BASE_URL = 'http://localhost:5000/api';

// Utility functions
const validateURL = (url) => {
  if (!url.trim()) return { valid: false, error: "URL cannot be empty" };
  
  // Add https:// if no protocol specified
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    url = 'https://' + url;
  }
  
  try {
    new URL(url);
    return { valid: true, url };
  } catch {
    return { valid: false, error: "Invalid URL format" };
  }
};

const openURLsWithPositions = async (urls, positions, delay) => {
  const windowPositions = {
    'top-left': { top: 0, left: 0, width: window.screen.width / 2, height: window.screen.height / 2 },
    'top-right': { top: 0, left: window.screen.width / 2, width: window.screen.width / 2, height: window.screen.height / 2 },
    'bottom-left': { top: window.screen.height / 2, left: 0, width: window.screen.width / 2, height: window.screen.height / 2 },
    'bottom-right': { top: window.screen.height / 2, left: window.screen.width / 2, width: window.screen.width / 2, height: window.screen.height / 2 },
    'center': { top: window.screen.height / 4, left: window.screen.width / 4, width: window.screen.width / 2, height: window.screen.height / 2 },
    'maximized': { top: 0, left: 0, width: window.screen.width, height: window.screen.height }
  };

  let existingWindow = null; // store reference for default case

  for (let i = 0; i < urls.length; i++) {
    const url = urls[i];
    const position = positions[url] || 'center';

    if (position === 'default') {
      // open in same browser window but different tabs
      if (!existingWindow || existingWindow.closed) {
        existingWindow = window.open(url, "_blank"); // first one
      } else {
        existingWindow = window.open(url, "_blank"); // new tab in same window
      }
    } else {
      const pos = windowPositions[position];
      const features = `width=${pos.width},height=${pos.height},left=${pos.left},top=${pos.top},resizable=yes,scrollbars=yes`;
      window.open(url, `_blank_${i}`, features);
    }

    if (i < urls.length - 1) {
      await new Promise(resolve => setTimeout(resolve, delay * 1000));
    }
  }
};


// Components
const URLInput = ({ onAdd }) => {
  const [url, setUrl] = useState('');
  const [isValidating, setIsValidating] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!url.trim()) return;

    setIsValidating(true);
    const validation = validateURL(url);
    
    if (!validation.valid) {
      toast.error(validation.error);
      setIsValidating(false);
      return;
    }

    onAdd(validation.url);
    setUrl('');
    setIsValidating(false);
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2 mb-4">
      <div className="flex-1 relative">
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Enter URL (e.g., google.com or https://github.com)"
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200"
          disabled={isValidating}
        />
        {isValidating && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-500"></div>
          </div>
        )}
      </div>
      <button
        type="submit"
        disabled={isValidating}
        className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50"
      >
        <Plus className="w-5 h-5" />
      </button>
    </form>
  );
};

const CollectionCard = ({ collection, onEdit, onDelete, onLaunch,  onShare, darkMode }) => {
  const [isLaunching, setIsLaunching] = useState(false);
  
  const themeGradients = {
    'gradient-blue': 'from-blue-500 to-cyan-500',
    'gradient-purple': 'from-purple-500 to-pink-500',
    'gradient-green': 'from-green-500 to-emerald-500',
    'gradient-orange': 'from-orange-500 to-red-500',
    'gradient-pink': 'from-pink-500 to-rose-500',
    'gradient-indigo': 'from-indigo-500 to-purple-500'
  };

  const handleLaunch = async () => {
    setIsLaunching(true);
    try {
      await onLaunch(collection);
      toast.success(`Launched ${collection.urls.length} URLs!`);
    } catch (error) {
      toast.error('Failed to launch collection');
    } finally {
      setIsLaunching(false);
    }
  };

  return (
    <div className={`rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border ${
      darkMode 
        ? 'bg-gray-800 border-gray-700' 
        : 'bg-white border-gray-100'
    }`}>
      <div className={`h-2 bg-gradient-to-r ${themeGradients[collection.theme] || themeGradients['gradient-blue']} rounded-t-xl`}></div>
      
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className={`text-xl font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-800'}`}>
              {collection.name}
            </h3>
            {collection.description && (
              <p className={`text-sm mb-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {collection.description}
              </p>
            )}
          </div>
          <div className="flex gap-2">
            {collection.is_public && (
              <button
                onClick={() => onShare && onShare(collection)}
                className={`p-2 rounded-lg transition-colors ${
                  darkMode 
                    ? 'text-gray-400 hover:text-green-400 hover:bg-gray-700' 
                    : 'text-gray-500 hover:text-green-500 hover:bg-green-50'
                }`}
                title="Share Collection"
              >
                <Share2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={() => onEdit(collection)}
              className={`p-2 rounded-lg transition-colors ${
                darkMode 
                  ? 'text-gray-400 hover:text-blue-400 hover:bg-gray-700' 
                  : 'text-gray-500 hover:text-blue-500 hover:bg-blue-50'
              }`}
              title="Edit Collection"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            
            <button
              onClick={() => onDelete(collection.id)}
              className={`p-2 rounded-lg transition-colors ${
                darkMode 
                  ? 'text-gray-400 hover:text-red-400 hover:bg-gray-700' 
                  : 'text-gray-500 hover:text-red-500 hover:bg-red-50'
              }`}
              title="Delete Collection"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tags */}
        {collection.tags && collection.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {collection.tags.map((tag, index) => (
              <span
                key={index}
                className={`px-2 py-1 text-xs rounded-full flex items-center gap-1 ${
                  darkMode 
                    ? 'bg-gray-700 text-gray-300' 
                    : 'bg-gray-100 text-gray-700'
                }`}
              >
                <Tag className="w-3 h-3" />
                {tag}
              </span>
            ))}
          </div>
        )}

        {/* URLs preview */}
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <Globe className={`w-4 h-4 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`} />
            <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {collection.urls.length} URLs
            </span>
          </div>
          <div className="space-y-1">
            {collection.urls.slice(0, 3).map((url, index) => (
              <div 
                key={index} 
                className={`text-xs truncate px-2 py-1 rounded ${
                  darkMode 
                    ? 'text-gray-400 bg-gray-700/50' 
                    : 'text-gray-500 bg-gray-50'
                }`}
              >
                {url}
              </div>
            ))}
            {collection.urls.length > 3 && (
              <div className={`text-xs text-center py-1 ${
                darkMode ? 'text-gray-500' : 'text-gray-400'
              }`}>
                +{collection.urls.length - 3} more URLs
              </div>
            )}
          </div>
        </div>

        {/* Statistics */}
        <div className={`flex items-center gap-4 mb-4 text-xs ${
          darkMode ? 'text-gray-400' : 'text-gray-500'
        }`}>
          <div className="flex items-center gap-1">
            <BarChart3 className="w-3 h-3" />
            <span>{collection.usage_count || 0} launches</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{collection.delay_seconds}s delay</span>
          </div>
          {collection.last_used && (
            <div className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              <span>Last used: {new Date(collection.last_used).toLocaleDateString()}</span>
            </div>
          )}
        </div>

        {/* Launch button */}
        <button
          onClick={handleLaunch}
          disabled={isLaunching}
          className={`w-full py-3 px-4 bg-gradient-to-r ${themeGradients[collection.theme] || themeGradients['gradient-blue']} text-white rounded-lg hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-50`}
        >
          {isLaunching ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              <span>Launching...</span>
            </>
          ) : (
            <>
              <Rocket className="w-4 h-4" />
              <span>Launch Collection</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};

const CollectionModal = ({ collection, isOpen, onClose, onSave, darkMode }) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    urls: [],
    tags: [],
    delay_seconds: 1,
    theme: 'gradient-blue',
    is_public: false
  });
  const [currentUrl, setCurrentUrl] = useState('');
  const [currentTag, setCurrentTag] = useState('');
  const [windowPositions, setWindowPositions] = useState({});

  const themes = [
    { key: 'gradient-blue', name: 'Ocean Blue', class: 'from-blue-500 to-cyan-500' },
    { key: 'gradient-purple', name: 'Purple Magic', class: 'from-purple-500 to-pink-500' },
    { key: 'gradient-green', name: 'Nature Green', class: 'from-green-500 to-emerald-500' },
    { key: 'gradient-orange', name: 'Sunset Orange', class: 'from-orange-500 to-red-500' },
    { key: 'gradient-pink', name: 'Rose Pink', class: 'from-pink-500 to-rose-500' },
    { key: 'gradient-indigo', name: 'Deep Indigo', class: 'from-indigo-500 to-purple-500' }
  ];

  const positionOptions = [
    { key: 'default', name: 'Default' },
    { key: 'center', name: 'Center' },
    { key: 'top-left', name: 'Top Left' },
    { key: 'top-right', name: 'Top Right' },
    { key: 'bottom-left', name: 'Bottom Left' },
    { key: 'bottom-right', name: 'Bottom Right' },
    { key: 'maximized', name: 'Maximized' }
  ];

  useEffect(() => {
    if (collection) {
      setFormData({
        name: collection.name,
        description: collection.description || '',
        urls: [...collection.urls],
        tags: [...collection.tags],
        delay_seconds: collection.delay_seconds,
        theme: collection.theme,
        is_public: collection.is_public
      });
      setWindowPositions(collection.window_positions || {});
    } else {
      setFormData({
        name: '',
        description: '',
        urls: [],
        tags: [],
        delay_seconds: 1,
        theme: 'gradient-blue',
        is_public: false
      });
      setWindowPositions({});
    }
  }, [collection]);

  const addUrl = () => {
    if (!currentUrl.trim()) return;
    
    const validation = validateURL(currentUrl);
    if (!validation.valid) {
      toast.error(validation.error);
      return;
    }

    if (formData.urls.includes(validation.url)) {
      toast.error('URL already exists in collection');
      return;
    }

    setFormData(prev => ({
      ...prev,
      urls: [...prev.urls, validation.url]
    }));
    setWindowPositions(prev => ({
      ...prev,
      [validation.url]: 'default'
    }));
    setCurrentUrl('');
    toast.success('URL added successfully');
  };

  const removeUrl = (index) => {
    const urlToRemove = formData.urls[index];
    setFormData(prev => ({
      ...prev,
      urls: prev.urls.filter((_, i) => i !== index)
    }));
    setWindowPositions(prev => {
      const newPositions = { ...prev };
      delete newPositions[urlToRemove];
      return newPositions;
    });
  };

  const addTag = () => {
    if (!currentTag.trim()) return;
    
    if (formData.tags.includes(currentTag.trim())) {
      toast.error('Tag already exists');
      return;
    }

    setFormData(prev => ({
      ...prev,
      tags: [...prev.tags, currentTag.trim()]
    }));
    setCurrentTag('');
  };

  const removeTag = (index) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter((_, i) => i !== index)
    }));
  };

  const handleSave = () => {
    if (!formData.name.trim()) {
      toast.error('Collection name is required');
      return;
    }
    
    if (formData.urls.length === 0) {
      toast.error('At least one URL is required');
      return;
    }

    onSave({
      ...formData,
      window_positions: windowPositions
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className={`rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto ${
        darkMode ? 'bg-gray-800' : 'bg-white'
      }`}>
        <div className={`p-6 bg-gradient-to-r ${themes.find(t => t.key === formData.theme)?.class} text-white rounded-t-xl`}>
          <h2 className="text-2xl font-bold">
            {collection ? 'Edit Collection' : 'Create New Collection'}
          </h2>
        </div>

        <div className="p-6">
          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label className={`block text-sm font-medium mb-2 ${
                darkMode ? 'text-gray-300' : 'text-gray-700'
              }`}>
                Collection Name *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  darkMode 
                    ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400' 
                    : 'bg-white border-gray-300 text-gray-900'
                }`}
                placeholder="Enter collection name"
              />
            </div>
            
            <div>
              <label className={`block text-sm font-medium mb-2 ${
                darkMode ? 'text-gray-300' : 'text-gray-700'
              }`}>
                Launch Delay (seconds)
              </label>
              <input
                type="number"
                min="0"
                max="10"
                value={formData.delay_seconds}
                onChange={(e) => setFormData(prev => ({ ...prev, delay_seconds: parseInt(e.target.value) || 1 }))}
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  darkMode 
                    ? 'bg-gray-700 border-gray-600 text-white' 
                    : 'bg-white border-gray-300 text-gray-900'
                }`}
              />
            </div>
          </div>

          <div className="mb-6">
            <label className={`block text-sm font-medium mb-2 ${
              darkMode ? 'text-gray-300' : 'text-gray-700'
            }`}>
              Description
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                darkMode 
                  ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400' 
                  : 'bg-white border-gray-300 text-gray-900'
              }`}
              rows="3"
              placeholder="Optional description"
            />
          </div>

          {/* Theme Selection */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Theme
            </label>
            <div className="grid grid-cols-3 gap-3">
              {themes.map((theme) => (
                <button
                  key={theme.key}
                  onClick={() => setFormData(prev => ({ ...prev, theme: theme.key }))}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    formData.theme === theme.key 
                      ? 'border-gray-800 ring-2 ring-gray-300' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className={`h-8 bg-gradient-to-r ${theme.class} rounded mb-2`}></div>
                  <div className="text-xs text-gray-600">{theme.name}</div>
                </button>
              ))}
            </div>
          </div>

          {/* URLs Section */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              URLs *
            </label>
            
            <div className="flex gap-2 mb-3">
              <input
                type="text"
                value={currentUrl}
                onChange={(e) => setCurrentUrl(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addUrl()}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter URL and press Enter"
              />
              <button
                onClick={addUrl}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              {formData.urls.map((url, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-800 truncate">{url}</div>
                  </div>
                  <select
                    value={windowPositions[url] || 'center'}
                    onChange={(e) => setWindowPositions(prev => ({ ...prev, [url]: e.target.value }))}
                    className="px-2 py-1 text-xs border border-gray-300 rounded"
                  >
                    {positionOptions.map((pos) => (
                      <option key={pos.key} value={pos.key}>{pos.name}</option>
                    ))}
                  </select>
                  <button
                    onClick={() => removeUrl(index)}
                    className="p-1 text-red-500 hover:text-red-700 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Tags Section */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Tags
            </label>
            
            <div className="flex gap-2 mb-3">
              <input
                type="text"
                value={currentTag}
                onChange={(e) => setCurrentTag(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addTag()}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter tag and press Enter"
              />
              <button
                onClick={addTag}
                className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
              >
                <Tag className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {formData.tags.map((tag, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full flex items-center gap-2"
                >
                  {tag}
                  <button
                    onClick={() => removeTag(index)}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Sharing Options */}
          <div className="mb-6">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={formData.is_public}
                onChange={(e) => setFormData(prev => ({ ...prev, is_public: e.target.checked }))}
                className="rounded"
              />
              <span className="text-sm font-medium text-gray-700">Make this collection shareable</span>
            </label>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 justify-end">
            <button
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className={`px-6 py-2 bg-gradient-to-r ${themes.find(t => t.key === formData.theme)?.class} text-white rounded-lg hover:shadow-lg transition-all`}
            >
              {collection ? 'Update Collection' : 'Create Collection'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const ShareModal = ({ collection, isOpen, onClose, darkMode }) => {
  const [shareUrl, setShareUrl] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (collection && isOpen) {
      const url = `${window.location.origin}/share/${collection.share_id}`;
      setShareUrl(url);
    }
  }, [collection, isOpen]);

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      toast.success('Share URL copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error('Failed to copy URL');
    }
  };

  if (!isOpen || !collection) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <Share2 className="w-6 h-6 text-blue-500" />
            <h2 className="text-xl font-bold text-gray-800">Share Collection</h2>
          </div>
          
          <p className="text-gray-600 mb-4">
            Share "{collection.name}" with others. Anyone with this link can view and launch this collection.
          </p>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Share URL
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={shareUrl}
                readOnly
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-sm"
              />
              <button
                onClick={copyToClipboard}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
              >
                {copied ? 'Copied!' : 'Copy'}
              </button>
            </div>
          </div>

          <div className="flex gap-3 justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatsModal = ({ stats, isOpen, onClose, darkMode }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="p-6 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-t-xl">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <BarChart3 className="w-6 h-6" />
            Usage Statistics
          </h2>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-gradient-to-r from-blue-50 to-cyan-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Collections</p>
                  <p className="text-2xl font-bold text-blue-600">{stats.total_collections}</p>
                </div>
                <Bookmark className="w-8 h-8 text-blue-500" />
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total URLs</p>
                  <p className="text-2xl font-bold text-green-600">{stats.total_urls}</p>
                </div>
                <Link className="w-8 h-8 text-green-500" />
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-lg">
              <div>
                <p className="text-sm text-gray-600">Popular Tags</p>
                <p className="text-2xl font-bold text-purple-600">{stats.popular_tags?.length || 0}</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Most Used Collections */}
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-orange-500" />
                Most Used Collections
              </h3>
              <div className="space-y-3">
                {stats.most_used?.slice(0, 5).map((collection, index) => (
                  <div key={collection.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-medium">{collection.name}</p>
                        <p className="text-xs text-gray-600">{collection.urls?.length || 0} URLs</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-orange-600">{collection.usage_count}</p>
                      <p className="text-xs text-gray-600">launches</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Collections */}
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Zap className="w-5 h-5 text-blue-500" />
                Recent Collections
              </h3>
              <div className="space-y-3">
                {stats.recent_collections?.slice(0, 5).map((collection) => (
                  <div key={collection.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">{collection.name}</p>
                      <p className="text-xs text-gray-600">{collection.urls?.length || 0} URLs</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-600">
                        {new Date(collection.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Popular Tags */}
          {stats.popular_tags && stats.popular_tags.length > 0 && (
            <div className="mt-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Tag className="w-5 h-5 text-green-500" />
                Popular Tags
              </h3>
              <div className="flex flex-wrap gap-2">
                {stats.popular_tags.slice(0, 20).map(([tag, count]) => (
                  <span
                    key={tag}
                    className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm flex items-center gap-1"
                  >
                    {tag} <span className="bg-blue-200 px-1 rounded text-xs">{count}</span>
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="flex justify-end mt-6">
            <button
              onClick={onClose}
              className="px-6 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:shadow-lg transition-all"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Main App Component
const App = () => {
  const [collections, setCollections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTag, setSelectedTag] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingCollection, setEditingCollection] = useState(null);
  const [shareModalData, setShareModalData] = useState({ isOpen: false, collection: null });
  const [stats, setStats] = useState(null);
  const [showStats, setShowStats] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  // Fetch collections
  const fetchCollections = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/collections`);
      const data = await response.json();
      if (data.success) {
        setCollections(data.collections);
      } else {
        toast.error('Failed to fetch collections');
      }
    } catch (error) {
      toast.error('Error connecting to server');
    } finally {
      setLoading(false);
    }
  };

  // Fetch stats
  const fetchStats = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/stats`);
      const data = await response.json();
      if (data.success) {
        setStats(data.stats);
      }
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  useEffect(() => {
    fetchCollections();
    fetchStats();
  }, []);

  // Handle collection save
  const handleSaveCollection = async (formData) => {
    try {
      const url = editingCollection 
        ? `${API_BASE_URL}/collections/${editingCollection.id}`
        : `${API_BASE_URL}/collections`;
      
      const method = editingCollection ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      
      if (data.success) {
        toast.success(editingCollection ? 'Collection updated!' : 'Collection created!');
        setShowModal(false);
        setEditingCollection(null);
        fetchCollections();
        fetchStats();
      } else {
        toast.error(data.error || 'Failed to save collection');
      }
    } catch (error) {
      toast.error('Error saving collection');
    }
  };

  // Handle collection launch
  const handleLaunchCollection = async (collection) => {
    try {
      await fetch(`${API_BASE_URL}/collections/${collection.id}/launch`, {
        method: 'POST',
      });

      await openURLsWithPositions(
        collection.urls,
        collection.window_positions || {},
        collection.delay_seconds
      );

      fetchCollections();
      fetchStats();
    } catch (error) {
      throw error;
    }
  };

  // Handle collection delete
  const handleDeleteCollection = async (id) => {
    if (!confirm('Are you sure you want to delete this collection?')) return;

    try {
      const response = await fetch(`${API_BASE_URL}/collections/${id}`, {
        method: 'DELETE',
      });

      const data = await response.json();
      
      if (data.success) {
        toast.success('Collection deleted!');
        fetchCollections();
        fetchStats();
      } else {
        toast.error('Failed to delete collection');
      }
    } catch (error) {
      toast.error('Error deleting collection');
    }
  };

  // Handle collection duplicate
  const handleDuplicateCollection = (collection) => {
    const duplicatedCollection = {
      ...collection,
      name: `${collection.name} (Copy)`,
      id: undefined
    };
    setEditingCollection(duplicatedCollection);
    setShowModal(true);
  };

  // Handle share collection
  const handleShareCollection = (collection) => {
    if (!collection.is_public) {
      toast.error('Collection must be public to share');
      return;
    }
    setShareModalData({ isOpen: true, collection });
  };

  // Handle export
  const handleExport = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/collections/export`);
      const data = await response.json();
      
      if (data.success) {
        const blob = new Blob([JSON.stringify(data.data, null, 2)], {
          type: 'application/json'
        });
        
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `daily-launcher-collections-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        toast.success('Collections exported successfully!');
      } else {
        toast.error('Failed to export collections');
      }
    } catch (error) {
      toast.error('Error exporting collections');
    }
  };

  // Handle import
  const handleImport = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const importData = JSON.parse(e.target.result);
        
        const response = await fetch(`${API_BASE_URL}/collections/import`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(importData),
        });

        const data = await response.json();
        
        if (data.success) {
          toast.success(`Imported ${data.imported_count} collections!`);
          if (data.errors.length > 0) {
            console.warn('Import errors:', data.errors);
          }
          fetchCollections();
          fetchStats();
        } else {
          toast.error('Failed to import collections');
        }
      } catch (error) {
        toast.error('Invalid file format');
      }
    };
    reader.readAsText(file);
    event.target.value = '';
  };

  // Filter collections
  const filteredCollections = collections.filter(collection => {
    const matchesSearch = collection.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         collection.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         collection.urls.some(url => url.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesTag = !selectedTag || collection.tags?.includes(selectedTag);
    
    return matchesSearch && matchesTag;
  });

  // Get all unique tags
  const allTags = [...new Set(collections.flatMap(collection => collection.tags || []))];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading Daily Launcher...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      darkMode 
        ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-indigo-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      <Toaster position="top-right" />
      
      {/* Header */}
      <header className={`sticky top-0 z-40 backdrop-blur-lg border-b transition-colors ${
        darkMode 
          ? 'bg-gray-900/80 border-gray-700' 
          : 'bg-white/80 border-gray-200'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                <Rocket className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  Daily Launcher
                </h1>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  Launch your daily URLs with ease
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowStats(true)}
                className={`p-2 rounded-lg transition-colors ${
                  darkMode 
                    ? 'text-gray-300 hover:text-white hover:bg-gray-700' 
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
                title="View Statistics"
              >
                <BarChart3 className="w-5 h-5" />
              </button>

              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`p-2 rounded-lg transition-colors ${
                  darkMode 
                    ? 'text-gray-300 hover:text-white hover:bg-gray-700' 
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
                title="Toggle Dark Mode"
              >
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExport}
                  className={`p-2 rounded-lg transition-colors ${
                    darkMode 
                      ? 'text-gray-300 hover:text-white hover:bg-gray-700' 
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                  title="Export Collections"
                >
                  <Download className="w-5 h-5" />
                </button>

                <label className={`p-2 rounded-lg transition-colors cursor-pointer ${
                  darkMode 
                    ? 'text-gray-300 hover:text-white hover:bg-gray-700' 
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`} title="Import Collections">
                  <Upload className="w-5 h-5" />
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImport}
                    className="hidden"
                  />
                </label>
              </div>

              <button
                onClick={() => {
                  setEditingCollection(null);
                  setShowModal(true);
                }}
                className="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden sm:inline">New Collection</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filter Bar */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 ${
                darkMode ? 'text-gray-400' : 'text-gray-500'
              }`} />
              <input
                type="text"
                placeholder="Search collections, URLs, or descriptions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={`w-full pl-10 pr-4 py-3 rounded-lg border focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200 ${
                  darkMode 
                    ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-400' 
                    : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                }`}
              />
            </div>

            {allTags.length > 0 && (
              <select
                value={selectedTag}
                onChange={(e) => setSelectedTag(e.target.value)}
                className={`px-4 py-3 rounded-lg border focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200 ${
                  darkMode 
                    ? 'bg-gray-800 border-gray-700 text-white' 
                    : 'bg-white border-gray-300 text-gray-900'
                }`}
              >
                <option value="">All Tags</option>
                {allTags.map(tag => (
                  <option key={tag} value={tag}>{tag}</option>
                ))}
              </select>
            )}
          </div>

          {/* Quick Stats */}
          <div className="mt-4 flex flex-wrap gap-4 text-sm">
            <span className={`px-3 py-1 rounded-full ${
              darkMode ? 'bg-gray-800 text-gray-300' : 'bg-gray-100 text-gray-600'
            }`}>
              {filteredCollections.length} collections
            </span>
            <span className={`px-3 py-1 rounded-full ${
              darkMode ? 'bg-gray-800 text-gray-300' : 'bg-gray-100 text-gray-600'
            }`}>
              {filteredCollections.reduce((acc, col) => acc + col.urls.length, 0)} total URLs
            </span>
            {selectedTag && (
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full flex items-center gap-1">
                <Tag className="w-3 h-3" />
                {selectedTag}
                <button
                  onClick={() => setSelectedTag('')}
                  className="ml-1 text-blue-600 hover:text-blue-800"
                >
                  ×
                </button>
              </span>
            )}
          </div>
        </div>

        {/* Collections Grid */}
        {filteredCollections.length === 0 ? (
          <div className="text-center py-12">
            <div className={`w-24 h-24 mx-auto rounded-full flex items-center justify-center mb-4 ${
              darkMode ? 'bg-gray-800' : 'bg-gray-100'
            }`}>
              <Bookmark className={`w-12 h-12 ${darkMode ? 'text-gray-600' : 'text-gray-400'}`} />
            </div>
            <h3 className={`text-xl font-semibold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              {searchTerm || selectedTag ? 'No collections found' : 'No collections yet'}
            </h3>
            <p className={`mb-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {searchTerm || selectedTag 
                ? 'Try adjusting your search or filter criteria'
                : 'Create your first collection to get started with Daily Launcher'
              }
            </p>
            {!searchTerm && !selectedTag && (
              <button
                onClick={() => {
                  setEditingCollection(null);
                  setShowModal(true);
                }}
                className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl flex items-center gap-2 mx-auto"
              >
                <Plus className="w-5 h-5" />
                Create Your First Collection
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCollections.map((collection) => (
              <CollectionCard
                key={collection.id}
                collection={collection}
                onEdit={(col) => {
                  setEditingCollection(col);
                  setShowModal(true);
                }}
                onDelete={handleDeleteCollection}
                onLaunch={handleLaunchCollection}
                onDuplicate={handleDuplicateCollection}
                onShare={handleShareCollection}
                darkMode={darkMode}
              />
            ))}
          </div>
        )}

        {/* Keyboard Shortcuts Info */}
        <div className={`mt-12 p-4 rounded-lg border-2 border-dashed ${
          darkMode ? 'border-gray-700 bg-gray-800/50' : 'border-gray-300 bg-gray-50'
        }`}>
          <h3 className={`text-lg font-semibold mb-3 flex items-center gap-2 ${
            darkMode ? 'text-white' : 'text-gray-900'
          }`}>
            <Zap className="w-5 h-5 text-yellow-500" />
            Pro Tips & Keyboard Shortcuts
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <p className={`mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                <kbd className={`px-2 py-1 rounded text-xs ${
                  darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-200 text-gray-800'
                }`}>Ctrl + N</kbd> Create new collection
              </p>
              <p className={`mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                <kbd className={`px-2 py-1 rounded text-xs ${
                  darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-200 text-gray-800'
                }`}>Enter</kbd> Add URL or tag when typing
              </p>
            </div>
            <div>
              <p className={`mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                💡 URLs auto-complete with https:// if missing
              </p>
              <p className={`mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                🎯 Use tags to organize collections by category
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Modals */}
      <CollectionModal
        collection={editingCollection}
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          setEditingCollection(null);
        }}
        onSave={handleSaveCollection}
        darkMode={darkMode}
      />

      <ShareModal
        collection={shareModalData.collection}
        isOpen={shareModalData.isOpen}
        onClose={() => setShareModalData({ isOpen: false, collection: null })}
        darkMode={darkMode}
      />

      {stats && (
        <StatsModal
          stats={stats}
          isOpen={showStats}
          onClose={() => setShowStats(false)}
          darkMode={darkMode}
        />
      )}

      {/* Floating Action Button for Mobile */}
      <button
        onClick={() => {
          setEditingCollection(null);
          setShowModal(true);
        }}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-full shadow-lg hover:shadow-2xl transition-all duration-200 flex items-center justify-center lg:hidden z-30"
      >
        <Plus className="w-6 h-6" />
      </button>

      {/* Footer */}
      <footer className={`mt-16 py-8 border-t ${
        darkMode ? 'border-gray-700 bg-gray-900/50' : 'border-gray-200 bg-white/50'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Daily Launcher - Streamline your daily web browsing experience
            </p>
            <div className="flex justify-center items-center gap-4 mt-2">
              <span className={`text-xs flex items-center gap-1 ${darkMode ? 'text-gray-500' : 'text-gray-500'}`}>
                Made with <Heart className="w-3 h-3 text-red-500" /> for productivity
              </span>
            </div>
          </div>
        </div>
      </footer>

      {/* Global Keyboard Shortcuts */}
      <div
        className="hidden"
        onKeyDown={(e) => {
          if (e.ctrlKey && e.key === 'n') {
            e.preventDefault();
            setEditingCollection(null);
            setShowModal(true);
          }
        }}
      />
    </div>
  );
};

export default App;